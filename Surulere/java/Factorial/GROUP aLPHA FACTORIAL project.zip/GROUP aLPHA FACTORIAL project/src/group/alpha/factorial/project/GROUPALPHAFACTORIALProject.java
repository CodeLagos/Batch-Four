/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package group.alpha.factorial.project;
import java.util.Scanner;
/**
 *
 * @author hp
 */
public class GROUPALPHAFACTORIALProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input=new Scanner(System.in);
        int value;
        int fact=1;
         System.out.println("kindly input value");
        value=input.nextInt();
        int i=value;
        while (i!=0){
            fact=fact*i;
            i=i-1;
        }
        System.out.printf("the factorial is %d\n",fact);
        
    }
    
}
