/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temperatureconverter;
import java.util.Scanner;

/**
 *
 * @author hp
 */
public class Temperatureconverter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     Scanner input=new Scanner(System.in);
     double temp;
     double fahrenheit;
     int choice;
     
     System.out.println("to convert,select a number of your choice \n1=celsius to fahrenheit\n2=farenheit to celsius\n");
     choice=input.nextInt();
     if (choice==1){
    System.out.println("enter value for celsius");
    temp=input.nextDouble();
    fahrenheit=(temp*1.8)+32;
    System.out.printf("fahrenheit is %f\n",fahrenheit);
     }
    else if (choice==2){
    System.out.println("enter farenheit");
    fahrenheit=input.nextDouble();
    temp=(fahrenheit-32)/1.8;
    System.out.printf("celsius is %f\n",temp);
    }
    if (choice>2){
    System.out.println("Error,please enter correct value");
    
    }
        }
    }
    
     
     
     
     
    
    

